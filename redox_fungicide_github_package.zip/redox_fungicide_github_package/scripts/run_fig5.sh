#!/usr/bin/env bash
set -euo pipefail

OUTPUT_ROOT=${OUTPUT_ROOT:-./results/}
make main_fig5_spatial_dynamics OUTPUT_ROOT="${OUTPUT_ROOT}"
./bin/main_fig5_spatial_dynamics
