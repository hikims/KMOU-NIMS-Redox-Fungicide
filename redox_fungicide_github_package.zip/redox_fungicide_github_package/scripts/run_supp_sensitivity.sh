#!/usr/bin/env bash
set -euo pipefail

OUTPUT_ROOT=${OUTPUT_ROOT:-./results/}
make main_supp_figS1_threshold main_supp_figS2_S3_sensitivity_curves OUTPUT_ROOT="${OUTPUT_ROOT}"
./bin/main_supp_figS1_threshold
./bin/main_supp_figS2_S3_sensitivity_curves
