# Scripts

These shell scripts are convenience wrappers around the C++ drivers.
They assume the shared solver files (`functions.cpp`, `initial.cpp`, headers, and `parameters.h`) have been copied into `src/`.

- `run_table4.sh`: reproduces the data for the main-manuscript threshold comparison table.
- `run_fig5.sh`: reproduces the spatial snapshot data for Figure 5.
- `run_supp_sensitivity.sh`: reproduces the data for Supplementary Figures S1--S3.
