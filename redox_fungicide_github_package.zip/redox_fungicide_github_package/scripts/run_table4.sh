#!/usr/bin/env bash
set -euo pipefail

OUTPUT_ROOT=${OUTPUT_ROOT:-./results/}
MACHINE_LABEL=${MACHINE_LABEL:-local}
make main_fig2_table3_4_dose_time_maps OUTPUT_ROOT="${OUTPUT_ROOT}" MACHINE_LABEL="${MACHINE_LABEL}"
./bin/main_fig2_table3_4_dose_time_maps
