# Required shared solver files

The driver files in `drivers/` include the following project-specific files:

- `functions.hpp`
- `functions.cpp`
- `initial.hpp`
- `initial.cpp`
- `parameters.h`

Copy those shared solver files into this `src/` directory before compiling. They were not modified here because this package preserves the original driver filenames and focuses on organizing the reproducibility drivers for the manuscript figures and tables.
