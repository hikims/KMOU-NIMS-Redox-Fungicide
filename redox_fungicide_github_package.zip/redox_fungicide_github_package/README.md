# Redox-mediated fungicide suppression: reproducibility drivers

This repository contains the C++ driver programs used to generate the numerical data for the manuscript figures, tables, and supplementary figures. The filenames of the uploaded driver programs are preserved.

## Repository layout

```text
drivers/    C++ driver programs for manuscript figures and tables
configs/    Input case lists for parameter scans
src/        Place shared solver files here: functions.cpp, initial.cpp, headers, parameters.h
scripts/    Convenience shell scripts
results/    Default output root (ignored by git)
docs/       Reproduction manifest and notes
```

## Driver-to-paper map

| Paper item | Driver filename | Main output |
|---|---|---|
| Main Table 4 | `main_fig2_table3_4_dose_time_maps.cpp` | `results/TierB/summary/B2_threshold_comparison_<machine>.txt` |
| Main Figures 3--4 | `main_fig3_fig4_verification.cpp` | `results/time_series/` |
| Main Figure 5 | `main_fig5_spatial_dynamics.cpp` | `results/fig5_rerun_A0_0_2p25_5/data/A0_*/field_t*.dat` |
| Supplementary Figure S1 | `main_supp_figS1_threshold.cpp` | `results/threshold_parameter/summary/threshold_estimates.txt` |
| Supplementary Figures S2--S3 | `main_supp_figS2_S3_sensitivity_curves.cpp` | `results/sensitivity/summary/sensitivity_results.txt` |
| Supplementary Tables S1--S2 | `main_table_S1_S2_convergence.cpp` | `results/summary/summary_A0_vs_area.txt` and invariant diagnostics |

Note: the historical filename `main_fig2_table3_4_dose_time_maps.cpp` is preserved, but the current driver is the B2 finite-time threshold-comparison driver used for the main threshold table.

## What was cleaned

- Local absolute paths such as `/Users/mkim/Desktop/Research/fungicide_jh/` were replaced by a portable default output root `./results/`.
- The output root can be overridden at compile time using `OUTPUT_ROOT`, for example `make all OUTPUT_ROOT=/path/to/output/`.
- Input lists were moved to `configs/` with fallback support where appropriate.
- Driver filenames were not changed.
- The file `main_supp_figS1_threshold.cpp` in the uploaded batch was a duplicate of the Figure 5 driver; it has been replaced, under the same filename, with the threshold-scan driver corresponding to Supplementary Figure S1.

## Build

Before compiling, copy the shared solver files into `src/`:

```text
src/functions.hpp
src/functions.cpp
src/initial.hpp
src/initial.cpp
src/parameters.h
```

Then build all drivers:

```bash
./build.sh
```

or manually:

```bash
make all OUTPUT_ROOT=./results/ MACHINE_LABEL=local
```

The code requires a C++17 compiler and Intel TBB.

## Example runs

Generate the main threshold-comparison table data:

```bash
./scripts/run_table4.sh
```

Generate Figure 5 snapshot data:

```bash
./scripts/run_fig5.sh
```

Generate supplementary sensitivity data:

```bash
./scripts/run_supp_sensitivity.sh
```

## Output notes

The drivers can create large raw field files. For GitHub, keep only processed data needed to reproduce the manuscript figures and tables. Large raw simulation outputs should be archived separately or made available upon reasonable request.

## Citation

See `CITATION.cff`. Update the DOI after acceptance or after creating a Zenodo release.
